<?php
session_start();


if(isset($_SESSION['auth']))
{
	$_SESSION['message']="You are already registered";
	header("Location: index.php");
	exit(0);
}
  
 /*Above HTML  
 $fname_error = ''; 
 if(isset($_POST["register_btn"]))  
 {  
      if(empty($_POST["fname"]))  
      {  
           $fname_error = "<p>Please Enter Name</p>";  
      }  
      else  
      {  
           if(!preg_match("/^[a-zA-Z ]*$/", $_POST["fname"]))  
           {  
                $fname_error = "<p>Only Letters and whitespace allowed</p>";  
           }  
      }
  }
  */




include('includes/header.php');

include('includes/navbar.php');


?>

<div class="py-5">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-md-5">

				<?php include('message.php') ?>

				<div class="card">
        <div class="card-header">
        <h4>Register</h4>
        </div>
<div class="card-body">
	<form onsubmit="return validateForm()" action="registercode.php" method="POST" >
	<div class="form-group mb-3">
				<label>First Name</label>
				<input  required type="text" name="fname" id="fname" placeholder="Enter First Name " class="form-control" value="">
				<span id = "blankMsg" style="color:red"> </span>  
    
			</div>

			<div class="form-group mb-3">
				<label>Last Name</label>
				<input  required type="text" name="lname" id="lname" placeholder="Enter Last Name " class="form-control" value="">
				<span id = "charMsg" style="color:red"> </span> 
			</div>

<div class="form-group mb-3">
				<label>Email-Id</label>
				<input required type="email"  name="email" id="email" placeholder="Enter Email Address" class="form-control" value="">
				<span id = "message3" style="color:red"> </span>
			</div>

			

			<div class="form-group mb-3">
				<label>Password</label>
				<input required type="password" name="password" id = "pswd1" placeholder="Enter Password" class="form-control" value="">
				<span id = "message1" style="color:red"> </span>  
			</div>

			<div class="form-group mb-3">
				<label> Confirm Password</label>
				<input required type="password" name="cpassword" id = "pswd2"  placeholder="Confirm Password" class="form-control" value="">
				<span id = "message2" style="color:red"> </span>   
			</div>

			<div class="form-group mb-3">
				<button  required type="submit" name="register_btn" class="btn btn-primary">Register Now</button>
				<button  class ="btn btn-primary" type = "reset" value = "Reset" >Reset</button>
		</div>
</form>
	</div>
</div>
</div>
</div>
</div>



<?php
include('includes/footer.php');
?>